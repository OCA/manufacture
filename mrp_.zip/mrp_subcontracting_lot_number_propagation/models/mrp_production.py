# Copyright 2022 Camptocamp SA
# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl)


from odoo import api, models


class MrpProduction(models.Model):
    _inherit = "mrp.production"

    # def subcontracting_record_component(self):
    #     if self.is_lot_number_propagated and self.propagated_lot_producing:
    #         self._create_and_assign_propagated_lot_number()
    #     return super().subcontracting_record_component()

    @api.depends(
        # New field dependencies to compute the propagated lot on the
        # "mrp_production_subcontracting_form_view" view.
        "move_raw_ids.move_line_ids.quantity",
        "move_raw_ids.move_line_ids.lot_id",
    )
    def _compute_propagated_lot_producing(self):
        return super()._compute_propagated_lot_producing()

    def _sync_propagated_lot_to_subcontract_move(self):
        """Copy the propagated finished lots to the receipt move lines."""
        for order in self:
            sbc_move = order._get_subcontract_move()
            if not (order.is_lot_number_propagated and sbc_move):
                continue
            for lot in order.lot_producing_ids:
                lines = sbc_move.move_line_ids
                if lot in lines.lot_id:
                    continue
                free_line = lines.filtered(lambda ml: not ml.lot_id)[:1]
                if free_line:
                    free_line.lot_id = lot
                else:
                    self.env["stock.move.line"].create(
                        {
                            "move_id": sbc_move.id,
                            "picking_id": sbc_move.picking_id.id,
                            "product_id": sbc_move.product_id.id,
                            "product_uom_id": sbc_move.product_uom.id,
                            "quantity": 1,
                            "lot_id": lot.id,
                            "location_id": sbc_move.location_id.id,
                            "location_dest_id": sbc_move.location_dest_id.id,
                        }
                    )

    def _set_lot_number_propagation_data_from_bom(self):
        import logging

        _logger = logging.getLogger(__name__)
        _logger.info("=" * 120)
        _logger.info(
            "self :%s", self.read(["lot_producing_ids", "propagated_lot_producing"])
        )
        _logger.info("=" * 120)
        res = super()._set_lot_number_propagation_data_from_bom()
        _logger.info(
            "self :%s", self.read(["lot_producing_ids", "propagated_lot_producing"])
        )
        _logger.info("=" * 120)
        return res
