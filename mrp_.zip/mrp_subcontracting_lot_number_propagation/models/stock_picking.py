from odoo import models


class StockPicking(models.Model):
    _inherit = "stock.picking"

    def button_validate(self):
        for picking in self:
            productions = picking.move_ids.move_orig_ids.production_id.filtered(
                "is_lot_number_propagated"
            )
            for production in productions:
                if production.state in ("done", "cancel"):
                    continue
                production._create_and_assign_propagated_lot_number()
                production._sync_propagated_lot_to_subcontract_move()
        return super().button_validate()

    # def button_validate(self):
    #     for picking in self:
    #         productions = picking.move_ids.move_orig_ids.production_id.filtered(
    #             "is_lot_number_propagated"
    #         )
    #         for production in productions:
    #             if production.state in ("done", "cancel"):
    #                 continue
    #             production.move_raw_ids.filtered("move_line_ids").picked = True
    #             if not production.qty_producing:
    #                 production.qty_producing = production.product_qty
    #             production._create_and_assign_propagated_lot_number()
    #             production._sync_propagated_lot_to_subcontract_move()
    #     return super().button_validate()
